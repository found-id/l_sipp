README: Taruh gambar untuk halaman autentikasi di sini

Rekomendasi gambar:
1. login-bg.jpg atau login-bg.png (untuk halaman login)
2. register-bg.jpg atau register-bg.png (untuk halaman register)
3. complete-profile-bg.jpg atau complete-profile-bg.png (untuk halaman lengkapi profil)

Ukuran ideal: 1920x1080px atau rasio 16:9
Format: JPG atau PNG
