<!-- Dosen Pembimbing Dashboard -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <!-- Mahasiswa Bimbingan -->
    <div class="group bg-white overflow-hidden shadow-lg rounded-2xl transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl border border-gray-100">
        <div class="p-6 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full -mr-16 -mt-16 opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            <div class="relative z-10">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                        <i class="fas fa-users text-2xl text-white"></i>
                    </div>
                    <div class="bg-blue-100 text-blue-600 text-xs font-bold px-3 py-1 rounded-full">Bimbingan</div>
                </div>
                <dt class="text-sm font-medium text-gray-500 mb-2">Mahasiswa Bimbingan</dt>
                <dd class="text-3xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors"><?php echo e($stats['mahasiswa_bimbingan']); ?></dd>
                <p class="text-xs text-gray-400 mt-1">mahasiswa dibimbing</p>
            </div>
        </div>
    </div>

    <!-- Berkas Perlu Validasi -->
    <div class="group bg-white overflow-hidden shadow-lg rounded-2xl transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl border border-gray-100">
        <div class="p-6 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-yellow-50 rounded-full -mr-16 -mt-16 opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            <div class="relative z-10">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-14 h-14 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-xl flex items-center justify-center shadow-lg transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                        <i class="fas fa-clock text-2xl text-white"></i>
                    </div>
                    <div class="bg-yellow-100 text-yellow-700 text-xs font-bold px-3 py-1 rounded-full">Pending</div>
                </div>
                <dt class="text-sm font-medium text-gray-500 mb-2">Perlu Validasi</dt>
                <dd class="text-3xl font-bold text-gray-900 group-hover:text-yellow-600 transition-colors"><?php echo e($stats['berkas_perlu_validasi']); ?></dd>
                <p class="text-xs text-gray-400 mt-1">berkas menunggu</p>
            </div>
        </div>
    </div>

    <!-- Berkas Tervalidasi -->
    <div class="group bg-white overflow-hidden shadow-lg rounded-2xl transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl border border-gray-100">
        <div class="p-6 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-green-50 rounded-full -mr-16 -mt-16 opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            <div class="relative z-10">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-14 h-14 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                        <i class="fas fa-check-circle text-2xl text-white"></i>
                    </div>
                    <div class="bg-green-100 text-green-700 text-xs font-bold px-3 py-1 rounded-full">Valid</div>
                </div>
                <dt class="text-sm font-medium text-gray-500 mb-2">Tervalidasi</dt>
                <dd class="text-3xl font-bold text-gray-900 group-hover:text-green-600 transition-colors"><?php echo e($stats['berkas_tervalidasi']); ?></dd>
                <p class="text-xs text-gray-400 mt-1">berkas selesai</p>
            </div>
        </div>
    </div>

    <!-- Total Mitra -->
    <div class="group bg-white overflow-hidden shadow-lg rounded-2xl transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl border border-gray-100">
        <div class="p-6 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-purple-50 rounded-full -mr-16 -mt-16 opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            <div class="relative z-10">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-14 h-14 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
                        <i class="fas fa-building text-2xl text-white"></i>
                    </div>
                    <div class="bg-purple-100 text-purple-600 text-xs font-bold px-3 py-1 rounded-full">Mitra</div>
                </div>
                <dt class="text-sm font-medium text-gray-500 mb-2">Total Mitra</dt>
                <dd class="text-3xl font-bold text-gray-900 group-hover:text-purple-600 transition-colors"><?php echo e($stats['total_mitra']); ?></dd>
                <p class="text-xs text-gray-400 mt-1">instansi tersedia</p>
            </div>
        </div>
    </div>
</div>

<!-- Mahasiswa Bimbingan List -->
<div class="mt-8">
    <div class="bg-white shadow-lg rounded-2xl border border-gray-100 overflow-hidden">
        <div class="bg-gradient-to-r from-gray-50 to-gray-100 px-6 py-5 border-b border-gray-200">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center mr-3">
                    <i class="fas fa-users text-white"></i>
                </div>
                <div>
                    <h3 class="text-lg font-bold text-gray-900">Mahasiswa Bimbingan</h3>
                    <p class="text-xs text-gray-600">Daftar mahasiswa yang Anda bimbing</p>
                </div>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-12">
                            No
                        </th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Mahasiswa
                        </th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                            Semester
                        </th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-36">
                            Status PKL
                        </th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-20">
                            IPK
                        </th>
                        <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-40">
                            Status
                        </th>
                        <th scope="col" class="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                            Aksi
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $stats['mahasiswa_bimbingan_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $profil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                            <?php echo e($index + 1); ?>

                        </td>
                        <td class="px-4 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10">
                                    <?php if($profil->user && $profil->user->photo && $profil->user->google_linked): ?>
                                        <img src="<?php echo e($profil->user->photo); ?>"
                                             alt="<?php echo e($profil->user->name); ?>"
                                             class="h-10 w-10 rounded-full object-cover"
                                             onerror="this.onerror=null; this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                        <div class="h-10 w-10 rounded-full bg-blue-100 items-center justify-center hidden">
                                            <i class="fas fa-user text-blue-600"></i>
                                        </div>
                                    <?php else: ?>
                                        <div class="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                            <i class="fas fa-user text-blue-600"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900"><?php echo e($profil->user->name ?? 'N/A'); ?></div>
                                    <div class="text-sm text-gray-500">NIM: <?php echo e($profil->nim ?? 'N/A'); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="px-4 py-4 whitespace-nowrap">
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-800">
                                <i class="fas fa-graduation-cap mr-1"></i>
                                Semester <?php echo e($profil->semester ?? '-'); ?>

                            </span>
                        </td>
                        <td class="px-4 py-4 whitespace-nowrap">
                            <?php
                                $dbStatusPkl = $profil->status_pkl ?? 'siap';
                                if ($dbStatusPkl === 'selesai') {
                                    $statusPKL = 'Selesai PKL';
                                    $statusColor = 'green';
                                    $statusIcon = 'fa-check-circle';
                                } elseif ($dbStatusPkl === 'aktif') {
                                    $statusPKL = 'Aktif PKL';
                                    $statusColor = 'blue';
                                    $statusIcon = 'fa-building';
                                } else {
                                    $statusPKL = 'Menyiapkan Berkas';
                                    $statusColor = 'gray';
                                    $statusIcon = 'fa-file-alt';
                                }
                            ?>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-<?php echo e($statusColor); ?>-100 text-<?php echo e($statusColor); ?>-800">
                                <i class="fas <?php echo e($statusIcon); ?> mr-1"></i>
                                <?php echo e($statusPKL); ?>

                            </span>
                        </td>
                        <td class="px-4 py-4 whitespace-nowrap">
                            <?php if($profil->ipk): ?>
                                <span class="text-sm font-semibold <?php echo e($profil->ipk >= 3.0 ? 'text-green-600' : 'text-orange-600'); ?>">
                                    <?php echo e(number_format($profil->ipk, 2)); ?>

                                </span>
                            <?php else: ?>
                                <span class="text-sm text-gray-400">-</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-4 whitespace-nowrap">
                            <?php
                                $user = $profil->user;

                                // Pemberkasan Kelayakan (KHS Files)
                                $kelayakanStatus = 'incomplete';
                                if ($user) {
                                    $khsCount = $user->khs()->count();
                                    if ($khsCount > 0) {
                                        $hasValidated = $user->khs()->where('status_validasi', 'tervalidasi')->exists();
                                        $kelayakanStatus = $hasValidated ? 'validated' : 'complete';
                                    }
                                }

                                // Dokumen Pendukung (Google Drive)
                                $dokumenStatus = 'incomplete';
                                $hasPkkmb = !empty($profil->gdrive_pkkmb ?? '');
                                $hasEcourse = !empty($profil->gdrive_ecourse ?? '');
                                if ($hasPkkmb && $hasEcourse) {
                                    $statusDokPendukung = $profil->status_dokumen_pendukung ?? 'menunggu';
                                    $dokumenStatus = $statusDokPendukung === 'tervalidasi' ? 'validated' : 'complete';
                                }

                                // Instansi Mitra (Surat Balasan)
                                $mitraStatus = 'incomplete';
                                if ($user) {
                                    $suratBalasan = $user->suratBalasan()->latest()->first();
                                    if ($suratBalasan) {
                                        $mitraStatus = $suratBalasan->status_validasi === 'tervalidasi' ? 'validated' : 'complete';
                                    }
                                }

                                // Pemberkasan Akhir (Laporan PKL)
                                $akhirStatus = 'incomplete';
                                if ($user) {
                                    $laporan = $user->laporanPkl()->latest()->first();
                                    if ($laporan) {
                                        $akhirStatus = $laporan->status_validasi === 'tervalidasi' ? 'validated' : 'complete';
                                    }
                                }
                            ?>
                            <div class="flex items-center space-x-2">
                                <!-- Pemberkasan Kelayakan -->
                                <i class="fas fa-file-alt text-lg <?php if($kelayakanStatus === 'validated'): ?> text-blue-600 <?php elseif($kelayakanStatus === 'complete'): ?> text-green-600 <?php else: ?> text-gray-400 <?php endif; ?>" title="Pemberkasan Kelayakan"></i>
                                <!-- Dokumen Pendukung -->
                                <i class="fab fa-google-drive text-lg <?php if($dokumenStatus === 'validated'): ?> text-blue-600 <?php elseif($dokumenStatus === 'complete'): ?> text-green-600 <?php else: ?> text-gray-400 <?php endif; ?>" title="Dokumen Pendukung"></i>
                                <!-- Instansi Mitra -->
                                <i class="fas fa-envelope text-lg <?php if($mitraStatus === 'validated'): ?> text-blue-600 <?php elseif($mitraStatus === 'complete'): ?> text-green-600 <?php else: ?> text-gray-400 <?php endif; ?>" title="Instansi Mitra"></i>
                                <!-- Pemberkasan Akhir -->
                                <i class="fas fa-book text-lg <?php if($akhirStatus === 'validated'): ?> text-blue-600 <?php elseif($akhirStatus === 'complete'): ?> text-green-600 <?php else: ?> text-gray-400 <?php endif; ?>" title="Pemberkasan Akhir"></i>
                            </div>
                        </td>
                        <td class="px-4 py-4 whitespace-nowrap text-center">
                            <a href="<?php echo e(route('dospem.mahasiswa.detail', $profil->user->id ?? 0)); ?>" class="inline-flex items-center px-3 py-1.5 bg-blue-600 text-white text-xs rounded-lg hover:bg-blue-700 transition">
                                <i class="fas fa-eye mr-1"></i>
                                Detail
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-6 py-8 text-center text-gray-500">
                            <i class="fas fa-users text-gray-300 text-4xl mb-3"></i>
                            <p>Tidak ada mahasiswa bimbingan</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\l_sipp last 4\l_sipp\resources\views/dashboard/dospem.blade.php ENDPATH**/ ?>