<?php $__env->startSection('title', 'Dashboard - SIP PKL'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Welcome Section -->
    <div class="bg-white overflow-hidden shadow rounded-lg">
        <div class="px-4 py-5 sm:p-6">
            <h1 class="text-2xl font-bold text-gray-900">
                Selamat datang, <?php echo e(auth()->user()->name); ?>!
            </h1>
            <p class="mt-1 text-sm text-gray-600">
                Anda login sebagai <?php echo e(ucfirst(auth()->user()->role)); ?>

            </p>
        </div>
    </div>

    <!-- Role-based Dashboard Content -->
    <?php if(auth()->user()->role === 'mahasiswa'): ?>
        <?php echo $__env->make('dashboard.mahasiswa', ['stats' => $stats ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif(auth()->user()->role === 'dospem'): ?>
        <?php echo $__env->make('dashboard.dospem', ['stats' => $stats ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif(auth()->user()->role === 'admin'): ?>
        <?php echo $__env->make('dashboard.admin', ['stats' => $stats ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\l_sipp last 4\l_sipp\resources\views/dashboard/index.blade.php ENDPATH**/ ?>